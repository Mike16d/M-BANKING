
ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('fve_banking:openATM')
AddEventHandler('fve_banking:openATM', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local balance = xPlayer.getAccount('bank').money
    TriggerClientEvent('fve_banking:openATMMenu', source, balance)
end)

RegisterNetEvent('fve_banking:openBank')
AddEventHandler('fve_banking:openBank', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local balance = xPlayer.getAccount('bank').money
    TriggerClientEvent('fve_banking:openATMMenu', source, balance)
end)

RegisterNetEvent('fve_banking:withdraw')
AddEventHandler('fve_banking:withdraw', function(amount)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    if amount <= 0 then
        TriggerClientEvent('fve_banking:notify', source, 'Neplatná částka', 'error')
        return
    end
    
    local bankBalance = xPlayer.getAccount('bank').money
    
    if amount > bankBalance then
        TriggerClientEvent('fve_banking:notify', source, 'Nedostatek prostředků', 'error')
        return
    end
    
    xPlayer.removeAccountMoney('bank', amount)
    xPlayer.addMoney(amount)
    
    TriggerClientEvent('fve_banking:notify', source, 'Výběr $' .. amount .. ' úspěšný', 'success')
    
    local newBalance = xPlayer.getAccount('bank').money
    TriggerClientEvent('fve_banking:openATMMenu', source, newBalance)
end)

RegisterNetEvent('fve_banking:deposit')
AddEventHandler('fve_banking:deposit', function(amount)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    if amount <= 0 then
        TriggerClientEvent('fve_banking:notify', source, 'Neplatná částka', 'error')
        return
    end
    
    local playerMoney = xPlayer.getMoney()
    if amount > playerMoney then
        TriggerClientEvent('fve_banking:notify', source, 'Nedostatek peněz', 'error')
        return
    end
    
    xPlayer.removeMoney(amount)
    xPlayer.addAccountMoney('bank', amount)
    
    TriggerClientEvent('fve_banking:notify', source, 'Vklad $' .. amount .. ' úspěšný', 'success')
    
    local newBalance = xPlayer.getAccount('bank').money
    TriggerClientEvent('fve_banking:openATMMenu', source, newBalance)
end)

-- Transfer money
RegisterNetEvent('fve_banking:transfer')
AddEventHandler('fve_banking:transfer', function(targetId, amount)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local xTarget = ESX.GetPlayerFromId(targetId)
    
    if not xPlayer then return end
    
    if not xTarget then
        TriggerClientEvent('fve_banking:notify', source, 'Hráč nenalezen', 'error')
        return
    end
    
    if amount <= 0 then
        TriggerClientEvent('fve_banking:notify', source, 'Neplatná částka', 'error')
        return
    end
    
    local bankBalance = xPlayer.getAccount('bank').money
    
    if amount > bankBalance then
        TriggerClientEvent('fve_banking:notify', source, 'Nedostatek prostředků', 'error')
        return
    end
    
    xPlayer.removeAccountMoney('bank', amount)
    xTarget.addAccountMoney('bank', amount)
    
    TriggerClientEvent('fve_banking:notify', source, 'Převod $' .. amount .. ' úspěšný', 'success')
    TriggerClientEvent('fve_banking:notify', targetId, 'Přijali jste $' .. amount .. ' od ' .. xPlayer.getName(), 'success')
    
    local newBalance = xPlayer.getAccount('bank').money
    TriggerClientEvent('fve_banking:openATMMenu', source, newBalance)
end)
