ESX = exports['es_extended']:getSharedObject()
local ox_target = exports.ox_target

for i = 1, #Config.ATM.models do
    local model = Config.ATM.models[i]
    ox_target:addModel(model, {
        {
            name = 'atm_access',
            icon = 'fas fa-credit-card',
            label = 'Přístup k ATM',
            onSelect = function()
                TriggerServerEvent('fve_banking:openATM')
            end
        }
    })
end
for i = 1, #Config.Bank.locations do
    local location = Config.Bank.locations[i]

    local blip = AddBlipForCoord(location.coords.x, location.coords.y, location.coords.z)
    SetBlipSprite(blip, location.blip.sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, location.blip.scale)
    SetBlipColour(blip, location.blip.color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(location.blip.name)
    EndTextCommandSetBlipName(blip)

    ox_target:addSphereZone({
        coords = location.coords,
        radius = 2.0,
        options = {
            {
                name = 'bank_access',
                icon = 'fas fa-university',
                label = 'Přístup k bance',
                onSelect = function()
                    TriggerServerEvent('fve_banking:openATM')
                end
            }
        }
    })
end
RegisterNetEvent('fve_banking:openATMMenu')
AddEventHandler('fve_banking:openATMMenu', function(balance)
    lib.registerContext({
        id = 'atm_menu',
        title = 'Zůstatek: $' .. balance,
        options = {
            {
                title = 'Vložit',
                description = 'Vložení peněz na váš účet',
                icon = 'fas fa-hand-holding-usd',
                onSelect = function()
                    local input = lib.inputDialog('Vklad peněz', {
                        {
                            type = 'number',
                            label = 'Částka',
                            description = 'Zadejte částku k vložení',
                            min = 1,
                            required = true
                        }
                    })
                    
                    if input and input[1] then
                        TriggerServerEvent('fve_banking:deposit', input[1])
                    end
                end
            },
            {
                title = 'Vybrat',
                description = 'Vybrání peněz z vašeho účtu',
                icon = 'fas fa-wallet',
                onSelect = function()
                    local input = lib.inputDialog('Výběr peněz', {
                        {
                            type = 'number',
                            label = 'Částka',
                            description = 'Zadejte částku k výběru',
                            min = 1,
                            max = balance,
                            required = true
                        }
                    })
                    
                    if input and input[1] then
                        TriggerServerEvent('fve_banking:withdraw', input[1])
                    end
                end
            },
            {
                title = 'Převod',
                description = 'Převedení peněz z vašeho účtu na jinou osobu',
                icon = 'fas fa-exchange-alt',
                onSelect = function()
                    local input = lib.inputDialog('Převod peněz', {
                        {
                            type = 'input',
                            label = 'ID hráče',
                            description = 'Zadejte ID hráče',
                            required = true
                        },
                        {
                            type = 'number',
                            label = 'Částka',
                            description = 'Zadejte částku k převodu',
                            min = 1,
                            max = balance,
                            required = true
                        }
                    })
                    
                    if input and input[1] and input[2] then
                        TriggerServerEvent('fve_banking:transfer', input[1], input[2])
                    end
                end
            }
        }
    })
    
    lib.showContext('atm_menu')
end)

RegisterNetEvent('fve_banking:notify')
AddEventHandler('fve_banking:notify', function(message, type)
    lib.notify({
        title = 'ATM',
        description = message,
        type = type or 'info'
    })
end) 