Config = {}

Config.ATM = {
    models = {
        `prop_atm_01`,
        `prop_atm_02`, 
        `prop_atm_03`,
        `prop_fleeca_atm`
    },
    blip = {
        sprite = 500,
        color = 2,
        scale = 0.8,
        name = "ATM"
    }
}

Config.Bank = {
    locations = {
        {
            name = "Fleeca Bank - Legion Square",
            coords = vector3(149.9, -1040.46, 29.37),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        },
        {
            name = "Fleeca Bank - Hawick Ave",
            coords = vector3(313.374, -278.621, 54.170),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        },
        {
            name = "Fleeca Bank - Del Perro",
            coords = vector3(-350.993, -49.529, 49.042),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        },
        {
            name = "Fleeca Bank - Great Ocean Hwy",
            coords = vector3(-1212.980, -330.841, 37.787),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        },
        {
            name = "Fleeca Bank - Route 68",
            coords = vector3(-2962.582, 482.576, 15.703),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        },
        {
            name = "Fleeca Bank - Paleto Bay",
            coords = vector3(-112.410, 6469.295, 31.626),
            blip = {
                sprite = 108,
                color = 2,
                scale = 0.8,
                name = "Fleeca Bank"
            }
        }
    }
} 